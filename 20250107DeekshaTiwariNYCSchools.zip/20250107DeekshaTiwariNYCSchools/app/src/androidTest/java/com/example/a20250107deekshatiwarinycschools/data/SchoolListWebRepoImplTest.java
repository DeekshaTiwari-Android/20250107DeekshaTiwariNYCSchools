package com.example.a20250107deekshatiwarinycschools.data;

import com.example.a20250107deekshatiwarinycschools.domain.get_school_list_interactor.data.SchoolListResponse;
import com.example.a20250107deekshatiwarinycschools.entities.Borough;
import com.example.a20250107deekshatiwarinycschools.entities.School;
import com.example.a20250107deekshatiwarinycschools.network.FakeApiUrlProvider;
import com.example.a20250107deekshatiwarinycschools.network.TestHttpClient;
import com.example.a20250107deekshatiwarinycschools.network.api_url_provider.ApiUrlProvider;
import com.example.a20250107deekshatiwarinycschools.network.auth_token_provider.AuthTokenProvider;
import com.example.a20250107deekshatiwarinycschools.network.http_client.HttpClient;

import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;

public class SchoolListWebRepoImplTest {
    private HttpClient httpClient;
    private AuthTokenProvider authTokenProvider;
    private ApiUrlProvider apiUrlProvider;

    @Before
    public void setUp() {
        httpClient = TestHttpClient.getHttpClient();

        authTokenProvider = HashMap::new;
        apiUrlProvider = FakeApiUrlProvider.getApiUrlProvider();
    }

    @Test
    public void getSchools() {
        SchoolListWebRepoImpl schoolListWebRepo = new SchoolListWebRepoImpl(httpClient, authTokenProvider, apiUrlProvider);

        for(Borough Borough : Borough.values()) {

            schoolListWebRepo.getSchoolsByBorough(Borough)
                    .test()
                    .assertValue(SchoolListResponse::isSuccessful)
                    .assertValue(schoolListResponse -> !schoolListResponse.getSchools().isEmpty())
                    .assertValue(schoolListResponse -> {
                        //checking I am getting the Boroughs I expect for the request
                        for (School school : schoolListResponse.getSchools()){
                            if(school.getBorough() != Borough){
                                return false;
                            }
                        }
                        return true;
                    })
                    .assertComplete();
        }
    }
}