package com.example.a20250107deekshatiwarinycschools.network.auth_token_provider;

import java.util.Map;

public interface AuthTokenProvider {

   Map<String, String> getAuthTokenHeaders();

}
