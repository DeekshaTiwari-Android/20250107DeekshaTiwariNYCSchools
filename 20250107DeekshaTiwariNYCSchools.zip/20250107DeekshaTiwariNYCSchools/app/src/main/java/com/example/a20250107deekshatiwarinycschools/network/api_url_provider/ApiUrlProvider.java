package com.example.a20250107deekshatiwarinycschools.network.api_url_provider;

public interface ApiUrlProvider {

    String getSchoolListApi();

    String getSchoolSatApi();

}
