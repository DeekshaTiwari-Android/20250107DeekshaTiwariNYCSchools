package com.example.a20250107deekshatiwarinycschools.view.base;

import androidx.lifecycle.ViewModel;

import com.example.a20250107deekshatiwarinycschools.di.ComponentProvider;
import com.example.a20250107deekshatiwarinycschools.di.ComponentProviderImpl;

import io.reactivex.disposables.CompositeDisposable;


public class BaseViewModel extends ViewModel {

    protected final CompositeDisposable onPauseDisposable = new CompositeDisposable();
    protected final CompositeDisposable onDestroyDisposable = new CompositeDisposable();
    protected final ComponentProvider componentProvider = ComponentProviderImpl.getInstance();

}
