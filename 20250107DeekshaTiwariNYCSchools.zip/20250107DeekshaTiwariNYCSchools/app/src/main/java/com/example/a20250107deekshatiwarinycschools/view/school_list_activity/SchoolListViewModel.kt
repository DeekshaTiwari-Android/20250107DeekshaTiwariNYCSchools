package com.example.a20250107deekshatiwarinycschools.view.school_list_activity

import androidx.lifecycle.LiveData
import com.example.a20250107deekshatiwarinycschools.adapters.school_list_adapter.SchoolListItemUiModel

interface SchoolListViewModel {
    fun getSchoolList(): LiveData<SchoolListUiModel>
    fun onSchoolListItemSelected(schoolListItemUiModel: SchoolListItemUiModel)
}
