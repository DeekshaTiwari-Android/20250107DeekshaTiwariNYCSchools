package com.example.a20250107deekshatiwarinycschools.data.base;

import com.example.a20250107deekshatiwarinycschools.network.api_url_provider.ApiUrlProvider;
import com.example.a20250107deekshatiwarinycschools.network.auth_token_provider.AuthTokenProvider;
import com.example.a20250107deekshatiwarinycschools.network.http_client.HttpClient;

public abstract class AbstractWebRepo {

    protected final HttpClient httpClient;
    protected final AuthTokenProvider authTokenProvider;
    protected final ApiUrlProvider apiUrlProvider;

    public AbstractWebRepo(HttpClient httpClient, AuthTokenProvider authTokenProvider, ApiUrlProvider apiUrlProvider) {
        this.httpClient = httpClient;
        this.authTokenProvider = authTokenProvider;
        this.apiUrlProvider = apiUrlProvider;
    }

}
