package com.example.a20250107deekshatiwarinycschools.di;

import com.example.a20250107deekshatiwarinycschools.di.app_component.AppComponent;

public interface ComponentProvider {

    AppComponent getAppComponent();

}
