package com.example.a20250107deekshatiwarinycschools.di.school_list_component;

import com.example.a20250107deekshatiwarinycschools.view.school_list_activity.SchoolListActivity;
import com.example.a20250107deekshatiwarinycschools.view.school_list_activity.SchoolListActivity;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;

@Module
abstract public class SchoolListActivityModule {

    @ContributesAndroidInjector
    abstract SchoolListActivity contributeYourAndroidInjector();

}
