package com.example.a20250107deekshatiwarinycschools.domain.get_school_list_interactor;

import com.example.a20250107deekshatiwarinycschools.entities.School;

import java.util.List;

import io.reactivex.Completable;

public interface SchoolListDbRepo extends SchoolListRepo{

    Completable storeSchools(List<School> schools);

}
