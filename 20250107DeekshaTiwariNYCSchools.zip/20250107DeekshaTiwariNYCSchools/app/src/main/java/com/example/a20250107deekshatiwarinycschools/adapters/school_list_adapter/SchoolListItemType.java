package com.example.a20250107deekshatiwarinycschools.adapters.school_list_adapter;

public enum SchoolListItemType {

    BOROUGH_TITLE,

    SCHOOL_ITEM,

    SAT_SCORE_ITEM

}
