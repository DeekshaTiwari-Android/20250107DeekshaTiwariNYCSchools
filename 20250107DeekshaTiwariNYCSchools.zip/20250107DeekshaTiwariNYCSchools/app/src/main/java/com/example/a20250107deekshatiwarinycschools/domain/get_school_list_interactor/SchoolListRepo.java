package com.example.a20250107deekshatiwarinycschools.domain.get_school_list_interactor;

import com.example.a20250107deekshatiwarinycschools.domain.get_school_list_interactor.data.SchoolListResponse;
import com.example.a20250107deekshatiwarinycschools.entities.Borough;

import io.reactivex.Single;


public interface SchoolListRepo {

    Single<SchoolListResponse> getSchoolsByBorough(Borough borough);

}
