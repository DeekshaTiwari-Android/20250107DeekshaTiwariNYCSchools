package com.example.a20250107deekshatiwarinycschools.adapters.school_list_adapter;

public interface OnSchoolListItemSelectedListener {

    void onSchoolListItemSelected(SchoolListItemUiModel schoolListItemUiModel);

}
