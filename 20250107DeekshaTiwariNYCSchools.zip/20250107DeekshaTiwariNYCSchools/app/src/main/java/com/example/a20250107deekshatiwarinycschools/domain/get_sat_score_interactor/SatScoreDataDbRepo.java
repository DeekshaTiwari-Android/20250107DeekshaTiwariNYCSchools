package com.example.a20250107deekshatiwarinycschools.domain.get_sat_score_interactor;

import com.example.a20250107deekshatiwarinycschools.entities.SatScoreData;

import io.reactivex.Completable;

public interface SatScoreDataDbRepo extends SatScoreDataRepo{

    Completable storeSatData(SatScoreData satScoreData);

}
