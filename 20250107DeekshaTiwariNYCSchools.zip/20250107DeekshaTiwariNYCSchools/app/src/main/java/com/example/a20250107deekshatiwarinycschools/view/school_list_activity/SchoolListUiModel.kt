package com.example.a20250107deekshatiwarinycschools.view.school_list_activity

import com.example.a20250107deekshatiwarinycschools.adapters.school_list_adapter.SchoolListItemUiModel

data class SchoolListUiModel(val schoolListItemUiModels: List<SchoolListItemUiModel>, val errorMessage: String? = null)