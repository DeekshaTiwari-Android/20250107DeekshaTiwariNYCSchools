package com.example.a20250107deekshatiwarinycschools.di.app_component;

import com.example.a20250107deekshatiwarinycschools.data.SatScoreDataDbRepoImpl;
import com.example.a20250107deekshatiwarinycschools.data.SatScoreDataRepoImpl;
import com.example.a20250107deekshatiwarinycschools.domain.get_sat_score_interactor.GetSatScoreDataInteractor;
import com.example.a20250107deekshatiwarinycschools.domain.get_sat_score_interactor.SatScoreDataDbRepo;
import com.example.a20250107deekshatiwarinycschools.domain.get_sat_score_interactor.SatScoreDataRepo;
import com.example.a20250107deekshatiwarinycschools.domain.get_sat_score_interactor.impl.GetSatScoreDataInteractorImpl;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
class SatScoreModule {

    @Singleton
    @Provides
    static GetSatScoreDataInteractor getSatScoreDataInteractor(GetSatScoreDataInteractorImpl getSatScoreDataInteractor){
        return getSatScoreDataInteractor;
    }

    @Singleton
    @Provides
    static SatScoreDataRepo satScoredDataRepo(SatScoreDataRepoImpl satScoredDataRepo){
        return satScoredDataRepo;
    }

    @Singleton
    @Provides
    static SatScoreDataDbRepo satScoredDataDbRepo(SatScoreDataDbRepoImpl satScoredDataRepo){
        return satScoredDataRepo;
    }

}
